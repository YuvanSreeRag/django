from django.shortcuts import render
from .models import Vehicle
# Create your views here.

#def home(request):
#    return render(request, 'car/home.html', {})


def home(request):
        if request.method == 'POST':
            if request.POST.get('name') and request.POST.get('brand') and request.POST.get('hp') and request.POST.get('price') and request.POST.get('fuel') and request.POST.get('gear') and request.POST.get('mileage') and request.POST.get('airbag'):
                post=Vehicle()
                post.name= request.POST.get('name')
                post.brand= request.POST.get('brand')
                post.hp= request.POST.get('hp')
                post.price= request.POST.get('price')
                post.fuel= request.POST.get('fuel')
                post.gear= request.POST.get('gear')
                post.mileage= request.POST.get('mileage')
                post.airbag= request.POST.get('airbag')
                post.save()
                
                return render(request, 'car/home.html')  

        else:
                return render(request,'car/home.html')
