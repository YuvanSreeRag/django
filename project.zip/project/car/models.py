from django.db import models

# Create your models here.

class Vehicle(models.Model):
    name = models.CharField(max_length=50)
    brand = models.CharField(max_length=50)
    hp = models.IntegerField()
    price = models.IntegerField()
    fuel = models.CharField(max_length=10)
    gear = models.CharField(max_length=10)
    mileage = models.IntegerField()
    airbag = models.CharField(max_length=10)
